package com.example.waitingQueueApplication.Controller;

import com.example.waitingQueueApplication.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.waitingQueueApplication.service.QueueService;
import com.example.waitingQueueApplication.service.abstractfactory.ResourceFactory;

import java.util.Optional;


@RestController
@RequestMapping("/queue")
public class QueueController {

    @Autowired
    private QueueService queueService;

    @Autowired
    private ResourceFactory resourceFactory;

    @PostMapping("/enter")
    public String enterQueue(@RequestBody User user, @RequestParam String resourceType) {
        var resource = resourceFactory.createResource(resourceType);
        return queueService.enterQueue(user, resource);
    }

    @GetMapping("/status")
    public String checkQueueStatus(@RequestParam Long userId) {
        Optional<User> user = queueService.checkStatus(userId);
        return user.isPresent() ? "User " + userId + " is in the queue." : "User " + userId + " is not in the queue.";
    }

    @PostMapping("/exit")
    public String exitQueue(@RequestParam Long userId) {
        return queueService.exitQueue(userId);
    }
}
