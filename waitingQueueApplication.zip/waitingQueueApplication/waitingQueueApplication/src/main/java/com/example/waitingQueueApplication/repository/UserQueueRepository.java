package com.example.waitingQueueApplication.repository;

import com.example.waitingQueueApplication.model.User;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Repository
public class UserQueueRepository {

    private final Map<Long, User> userQueue = new HashMap<>();

    public void save(User user) {
        userQueue.put(user.getId(), user);
    }

    public Optional<User> findById(Long userId) {
        return Optional.ofNullable(userQueue.get(userId));
    }

    public void delete(User user) {
        userQueue.remove(user.getId());
    }
}
