package com.example.waitingQueueApplication.service;

import com.example.waitingQueueApplication.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.waitingQueueApplication.repository.UserQueueRepository;
import com.example.waitingQueueApplication.service.abstractfactory.Resource;

import java.util.Optional;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

@Service
public class QueueService {

    private final Queue<User> waitingQueue = new ConcurrentLinkedQueue<>();
    private final int capacity = 5;
    private int currentUsers = 0;

    @Autowired
    private UserQueueRepository userQueueRepository;

    public String enterQueue(User user, Resource resource) {
        if (currentUsers < capacity) {
            currentUsers++;
            return "User " + user.getId() + " is allowed to access " + resource.getResourceType();
        } else {
            waitingQueue.add(user);
            userQueueRepository.save(user);
            return "User " + user.getId() + " is in the waiting queue for " + resource.getResourceType();
        }
    }

    public Optional<User> checkStatus(Long userId) {
        return userQueueRepository.findById(userId);
    }

    public String exitQueue(Long userId) {
        if (currentUsers > 0) {
            currentUsers--;
            User nextUser = waitingQueue.poll();
            if (nextUser != null) {
                userQueueRepository.delete(nextUser);
                currentUsers++;
                return "User " + userId + " has exited. Next user " + nextUser.getId() + " can access the resource.";
            }
            return "User " + userId + " has exited.";
        }
        return "No users are currently being served.";
    }
}
