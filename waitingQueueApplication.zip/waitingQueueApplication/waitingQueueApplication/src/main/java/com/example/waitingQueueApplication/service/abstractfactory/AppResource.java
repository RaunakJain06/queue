package com.example.waitingQueueApplication.service.abstractfactory;

public class AppResource implements Resource {
    @Override
    public String getResourceType() {
        return "App";
    }
}