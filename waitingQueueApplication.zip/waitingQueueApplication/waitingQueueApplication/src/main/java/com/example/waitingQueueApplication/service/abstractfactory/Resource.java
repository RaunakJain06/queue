package com.example.waitingQueueApplication.service.abstractfactory;

public interface Resource {
    String getResourceType();
}
