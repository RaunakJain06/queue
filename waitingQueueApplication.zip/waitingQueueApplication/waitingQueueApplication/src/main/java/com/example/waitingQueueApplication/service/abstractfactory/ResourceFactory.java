package com.example.waitingQueueApplication.service.abstractfactory;
import org.springframework.stereotype.Component;

@Component
public class ResourceFactory {

    public Resource createResource(String resourceType) {
        return switch (resourceType.toLowerCase()) {
            case "app" -> new AppResource();
            case "web" -> new WebResource();
            case "shop" -> new ShopResource();
            default -> throw new IllegalArgumentException("Unknown resource type");
        };
    }
}
