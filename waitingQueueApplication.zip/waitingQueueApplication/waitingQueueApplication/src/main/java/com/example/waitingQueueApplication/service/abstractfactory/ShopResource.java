package com.example.waitingQueueApplication.service.abstractfactory;


public class ShopResource implements Resource {
    @Override
    public String getResourceType() {
        return "Shop";
    }
}