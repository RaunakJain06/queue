package com.example.waitingQueueApplication.service.abstractfactory;

public class WebResource implements Resource {
    @Override
    public String getResourceType() {
        return "Web";
    }
}
