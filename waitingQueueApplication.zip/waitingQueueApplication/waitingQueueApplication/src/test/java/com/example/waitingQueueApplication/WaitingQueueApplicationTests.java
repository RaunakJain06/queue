package com.example.waitingQueueApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WaitingQueueApplicationTests {

	@Test
	void contextLoads() {
	}

}
